﻿// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

using System;
using System.Collections;

namespace Microsoft.Build.Tasks
{
    /// <remarks>
    /// Represents a cache of inputs to a compilation-style task.
    /// </remarks>
    [Serializable()]
    internal class Dependencies
    {
        /// <summary>
        /// Hashtable of other dependency files.
        /// Key is filename and value is DependencyFile.
        /// </summary>
        private Hashtable _dependencies = new Hashtable();

        /// <summary>
        /// Look up a dependency file. Return null if its not there.
        /// </summary>
        /// <param name="filename"></param>
        /// <returns></returns>
        internal DependencyFile GetDependencyFile(string filename)
        {
            return (DependencyFile)_dependencies[filename];
        }


        /// <summary>
        /// Add a new dependency file.
        /// </summary>
        /// <param name="filename"></param>
        /// <returns></returns>
        internal void AddDependencyFile(string filename, DependencyFile file)
        {
            _dependencies[filename] = file;
        }

        /// <summary>
        /// Remove new dependency file.
        /// </summary>
        /// <param name="filename"></param>
        /// <returns></returns>
        internal void RemoveDependencyFile(string filename)
        {
            _dependencies.Remove(filename);
        }

        /// <summary>
        /// Remove all entries from the dependency table.
        /// </summary>
        internal void Clear()
        {
            _dependencies.Clear();
        }
    }
}